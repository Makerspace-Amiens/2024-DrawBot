---
layout: home
nav_order: 1
title: Accueil
---

# Bienvenue sur notre projet : Drawbot

C'est un plaisir de vous accueillir sur notre projet Drawbot! Notre documentation est là pour vous guider à travers ce projet passionnant et vous aider à découvrir tout ce que notre Drawbot peut accomplir.

![Illustration vectorielle colorée avec un fond blanc, montrant un atelier équipé pour un projet de conception mécanique, électronique et informatique](images/illustration.png)

## À propos du Projet

Permettez-nous de vous présenter notre projet Drawbot. Notre objectif est de créer un robot de dessin innovant et créatif capable de transfromer vos idées en oeuvres d'art tabgibles. Destiné aux amateurs d'art, aux makers et à toute personne désireuse de découvrir le monde fascinant de la robotique, notre Drawbot combine la technologie et créativité pour offir une expérience unique. En utilisant des moteurs pas à pas, des algorithmes de tracage précis et une interface conviviale, notre Drawbot permet à chacun de donner vie à ses dessins avec facilité et précision.

Avec la carte Arduino ESP32, notre drawbot se démarquera par sa connectivité avancée. En plus des fonctionnalités classiques des drawbots, le nôtre sera doté d'une connectivité WiFi et Bluetooth, permettant à l'utilisateur de l'utiliser à distance.

## Poster
![Poster projet](images/drawbot.png)

## Vidéo

Ici vous publierez la vidéo de votre projet. 
- Moins de 1min30
- Présentation du projet 
- Des explication du fonctionnement du projet
- Des vues du projet / Prototype / Application etc... 
- Des plans du fonctionnement (même basique ou des éléments séparés)
- Une conclusion
Si en stockage local : >50mo

<video src="images/intro_amiens.mp4" controls title="Title"  style="width: 100%;"></video>

---