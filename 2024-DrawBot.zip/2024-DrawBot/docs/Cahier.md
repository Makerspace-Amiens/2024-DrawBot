---
layout: default
nav_order: 3
title: Cahier des Charges
---

# Cahier des Charges


<img src="images/cahier.jpg" alt="cahier" width="700" height="100">

1. Contraintes techniques :
    - Compatibilité avec les moteurs pas à pas Nema 17 et le driver DRV8825.
    - Utilisation de courroies et poulies GT2 pour la transmission de mouvement.
    - Utilisation d'une alimentation électrique adaptée aux besoins des moteurs et de l'Arduino ESP32. 
2. Planning et échéancier :
    - Phase de conception et modélisation : 20 heures
    - Phase de développement et de construction : 45 heures
    - Phase de test et de débogage : 5 heures
    - Phase de documentation :  5 heures
3. Ressources nécessaires :
    - Matériel : Une carte Arduino, deux moteurs pas à pas, un driveur de moteur, matériaux de construction, imprrimante laser, imprrimante 3D, etc.
    - Logiciels : Environnement de développement Arduino, Logiciels de modélisation 3D, outils de gestion projet, etc.
    - Main-d'oeuvre : Notre equipe pour la construction documentation, modélisation, et les tests.
4. Critères d'évaluation :
    - Précision du traçage des dessins.
    - Fiabilité du Drawbot.
    - Qualité artistique des dessins réalisés.
    - Exhausitivité de la documentation fournie. 
5. Approbation et validation :
    -  La validation du projet final sera effectuée selon les critères d'évaluation définis pour garantir sa conformité aux attentes et aux besoins du projet.


Ce cahier de charges servira de guide pour le développement et la réalisation du notre projet, en assurant que toutes les exigences et les contraintes sont prises en compte tout au long du processus.

