---
layout: default
nav_order: 4
title: Études 
---

# Études et choix techniques

Dans cette section, nous examinons les choix techniques que nous avons effectués pour chaque composant et aspect du drawbot. Avec un budget de 250 euros, voici un aperçu de nos réflexions et de nos décisions: 

1. Arduino ESP32:
    - Fonctionne comme le cerveau du drawbot. Contrôlera les moteurs et recevra les commandes pour dessiner et qui sera utilisé via wifi ou encore bluetooth.
2. Deux moteurs pas à pas Nema 17 stepper moteur :
    - Nécessaires pour le mouvement dans les axes X et Y, ils sont suffisamment puissants pour déplacer le stylo et le support sur toute la surface de dessin.
3. Driver de moteur pas à pas DRV8825 :
    - Utilisé pour alimenter et contrôler les moteurs pas à pas à partir de l'Arduino. Permet un contrôle précis des moteurs pas à pas en fournissant la puissance nécessaire.
4. Support pour les moteurs :
	- Châssis ou cadre pour monter les moteurs et maintenir la stabilité du drawbot.
5. Courroies et poulies (GT2) :
	- Transmettent le mouvement entre les moteurs et les axes X et Y. Offrent un mouvement fluide et précis, idéal pour des applications nécessitant un positionnement précis.
6. Stylo ou marquer :
	- Utilisé par le drawbot pour dessiner sur le mur. Il doit être fixé solidement et capable d'être soulevé et abaissé facilement.
7. Plaque de support (Tableau Blanc ) :
    - Surface sur laquelle le dessin sera réalisé.
8. Fils et connecteurs :
    - Utilisés pour connecter les moteurs, les capteurs et d'autres composants à l'Arduino.  
9. Alimentation électrique :
	- Alimente l'ensemble du système. La tension et le courant fournis doivent être adaptés aux besoins des moteurs et de l'Arduino.
10. Logiciels et outils :
    - Nous utiliserons l'IDE Arduino pour développer le code de contrôle de drawbot, ainsi que des outils de modélisation 3D ou CAO pour concevoir le châssis et les supports.


En combinant soigneusement ces choix techniques, nous sommes condfiants dans notre capacité à concevoir et à consruire un drawbot performant, précis et créatif pour notre projet.

