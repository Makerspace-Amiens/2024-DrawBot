---
layout: default
nav_order: 2
title: Objectifs du projet
---

# Introduction

Dans cette partie, nous allons plonger dans le contexte et les objectifs du projet Drawbot. Notre objectif est de créer un robot de dessin innovant et créatif,apportant aussi une touche de magie dans le monde de l'art automatisé.

<img src="images/welcome.jpg" alt="welcome" width="700" height="100">


## Contexte du Projet

L'histoire du projet Drawbot a débuté avec l'enthousiasme de créer une voiture RC. Cependant, notre proposition a été rejeteée, et nous avons été confrontés au défi inattendu de développer un drawbot à la place. Ce changement de direction aurait pu être perçu comme une contrainte, mais il s'est véré être une opportunité excitante pour explorer de nouveaux horizons créatifs.

Alors que nous plongions dans le projet Drawbot, nous avons rapidement réalisé son potentiel innovant et artistique. En poussant les limites de notre imagination, nous avons découvert une nouvelle passion pour ce Drawbot et ses possibilités uniques. Ce changement de cap inattendu a ouvert  la voie  à des avenues créatives insoupçonnées, et nous sommes impatients de partager les fruits de notre exploration avec le monde entier.


## Objectifs du Projet

Dans le cadre du projet Drawbot, nous nous sommes fixés plusieurs objectifs afin de réaliser notre vision créative:

1. Construire un drawbot capable de tracer des dessins de manière précise sur une surface spécifique. 
2. Développer une interface utilisateur conviviale pour contrôler facilement le drawbot et importer des dessins à reproduire.
3. Optimiser les algorithmes de  traçage afin d'assurer un mouvement fluide et précis du stylo, garantissant ainsi la création des dessins de haute qualité.
4. Explorer différentes techniques artistique en expérimentant avec divers matériaux de dessin et configurations de stylo. 
5. Documenter chaque étape du processus de conception, de construction et d'utilisation du drawbot afin de le rendre accessible à d'autres passionés de robotique  et d'art. 




 